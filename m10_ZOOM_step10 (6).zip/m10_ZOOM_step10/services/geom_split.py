# -*- coding: utf-8 -*-
from core.types import LineSeg
from math import hypot

_EPS = 1e-9  # tolerance pro krajní body (dotyk koncem čáry)

def intersect(a, b):
    x1,y1,x2,y2 = a.x1,a.y1,a.x2,a.y2
    x3,y3,x4,y4 = b.x1,b.y1,b.x2,b.y2
    den = (x1-x2)*(y3-y4) - (y1-y2)*(x3-x4)
    if den == 0:
        return None
    t = ((x1-x3)*(y3-y4) - (y1-y3)*(x3-x4)) / den
    u = ((x1-x3)*(y1-y2) - (y1-y3)*(x1-x2)) / den
    if -_EPS <= t <= 1+_EPS and -_EPS <= u <= 1+_EPS:
        t = max(0.0, min(1.0, t))
        return (x1 + t*(x2-x1), y1 + t*(y2-y1))
    return None

def split_line(line, pts):
    pts = [(line.x1,line.y1)] + pts + [(line.x2,line.y2)]
    dx = line.x2-line.x1; dy = line.y2-line.y1; L = dx*dx+dy*dy
    def t(p): return ((p[0]-line.x1)*dx + (p[1]-line.y1)*dy) / L if L else 0
    pts = sorted(pts, key=t)
    # Deduplikace bodů, které jsou příliš blízko sebe
    deduped = [pts[0]]
    for p in pts[1:]:
        if hypot(p[0]-deduped[-1][0], p[1]-deduped[-1][1]) > 1e-6:
            deduped.append(p)
    out = []
    for i in range(len(deduped)-1):
        x1,y1 = deduped[i]; x2,y2 = deduped[i+1]
        if hypot(x2-x1, y2-y1) > 1e-6:
            out.append(LineSeg(x1,y1,x2,y2))
    return out
