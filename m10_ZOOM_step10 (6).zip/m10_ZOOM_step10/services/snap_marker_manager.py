# -*- coding: utf-8 -*-
"""SnapMarkerManager — prioritní správce snap markerů.

Každý frame nástroje volají propose(kind, x, y).
Na konci framu flush() vykreslí marker s nejvyšší prioritou
a smaže ostatní kandidáty.

Priorita (nižší = vyšší):
    0  line_end
    1  line_mid
    2  hv_isect
    3  line_body
"""
from __future__ import annotations
from typing import Optional
from core import tracer

_PRIORITY: dict[str, int] = {
    'line_end':  0,
    'line_mid':  1,
    'hv_isect':  2,
    'line_body': 3,
    'grid':      4,
}

class SnapMarkerManager:
    def __init__(self, overlays, viewport=None):
        self._overlays = overlays
        self._viewport = viewport
        self._candidates: list[tuple[int, float, float, str]] = []
        # (priority, x, y, kind)

    def propose(self, kind: str, x: float, y: float) -> None:
        """Nahlásí kandidáta. Volat z nástroje při on_move."""
        pri = _PRIORITY.get(kind, 99)
        self._candidates.append((pri, x, y, kind))
        tracer.trace('MARKER', 'propose', kind=kind, x=round(x,1), y=round(y,1), pri=pri)

    def flush(self) -> None:
        """Vykreslí vítěze, smaže kandidáty. Volat na konci on_move."""
        if not self._candidates:
            self._overlays.clear_snap_marker()
            tracer.trace('MARKER', 'flush', winner=None)
            return
        winner = min(self._candidates, key=lambda c: c[0])
        pri, x, y, kind = winner
        tracer.trace('MARKER', 'flush', winner=kind, x=round(x,1), y=round(y,1),
                     candidates=len(self._candidates))
        # transformuj do canvas-space pokud máme viewport
        if self._viewport is not None:
            cx, cy = self._viewport.to_canvas(x, y)
        else:
            cx, cy = x, y
        self._overlays.draw_snap_marker(kind, cx, cy)
        self._candidates.clear()

    def clear(self) -> None:
        """Zruší kandidáty a smaže marker — volat při cancel/tool change."""
        self._candidates.clear()
        self._overlays.clear_snap_marker()
        tracer.trace('MARKER', 'clear')
