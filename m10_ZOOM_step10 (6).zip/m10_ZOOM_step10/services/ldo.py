
# -*- coding: utf-8 -*-
from __future__ import annotations

class LDOService:
    def __init__(self, canvas, viewport=None):
        self.canvas = canvas
        self._viewport = viewport
    def clear_half_axis(self):
        try: self.canvas.delete('hv_axis')
        except Exception: pass
    def half_axis(self, x0, y0, x, y, mode):
        try: self.canvas.delete('hv_axis')
        except Exception: pass
        try:
            w = int(self.canvas.winfo_width()); h = int(self.canvas.winfo_height())
            if w <= 2 or h <= 2:
                w = int(self.canvas.winfo_reqwidth()); h = int(self.canvas.winfo_reqheight())
        except Exception:
            w, h = 1000, 700
        # transform doc-space origin to canvas-space
        if self._viewport is not None:
            cx0, cy0 = self._viewport.to_canvas(x0, y0)
        else:
            cx0, cy0 = x0, y0
        M = 8
        if mode == 'h':
            if x >= x0: x1,y1,x2,y2 = cx0,cy0, w+M,cy0
            else: x1,y1,x2,y2 = cx0,cy0, -M, cy0
        else:
            if y >= y0: x1,y1,x2,y2 = cx0,cy0, cx0, h+M
            else: x1,y1,x2,y2 = cx0,cy0, cx0, -M
        try:
            self.canvas.create_line(x1,y1,x2,y2, fill='#0a6', dash=(3,2), width=1, tags=('hv_axis',))
        except Exception:
            pass
