
# -*- coding: utf-8 -*-
from __future__ import annotations

class OverlaysService:
    def __init__(self, canvas):
        self.canvas = canvas
    def clear(self):
        for tag in ('handles', 'pivot', 'sel_box', 'rubber_band', 'snap_marker'):
            try: self.canvas.delete(tag)
            except Exception: pass
    def draw_handles(self, points, size=6, color='#06c', fill=''):
        cv = self.canvas
        try: cv.delete('handles')
        except Exception: pass
        s = size // 2
        for (x,y) in points:
            try:
                cv.create_rectangle(x-s, y-s, x+s, y+s, outline=color, fill=fill, width=1, tags=('handles',))
            except Exception:
                pass
    def draw_pivot(self, x, y, r=5, outline='#c60', fill=''):
        cv = self.canvas
        try: cv.delete('pivot')
        except Exception: pass
        try:
            cv.create_oval(x-r, y-r, x+r, y+r, outline=outline, fill=fill, width=1, tags=('pivot',))
        except Exception:
            pass
    def handle_size(self):
        return 6

    def draw_trim_preview(self,x1,y1,x2,y2,color='#c00'):
        cv=self.canvas
        try: cv.delete('trim_preview')
        except: pass
        try: cv.create_line(x1,y1,x2,y2,fill=color,width=2,dash=(4,2),tags=('trim_preview',))
        except: pass

    def draw_group_handles(self, handles, size=6,
                           color='#06c', pivot_color='#c60'):
        """Nakreslí handles skupiny z selection_handles.group_handles().

        Každý Handle je NamedTuple(name, x, y).
        Pivot se kreslí jako kroužek, ostatní jako čtverečky.
        """
        cv = self.canvas
        try: cv.delete('handles')
        except Exception: pass
        try: cv.delete('pivot')
        except Exception: pass
        s = size // 2
        for h in handles:
            x, y = h.x, h.y
            if h.name == 'pivot':
                r = s + 1
                try:
                    cv.create_oval(x-r, y-r, x+r, y+r,
                                   outline=pivot_color, fill='', width=1,
                                   tags=('pivot',))
                except Exception:
                    pass
            else:
                try:
                    cv.create_rectangle(x-s, y-s, x+s, y+s,
                                        outline=color, fill='', width=1,
                                        tags=('handles',))
                except Exception:
                    pass

    def draw_selection_boxes(self, boxes, color='#06c'):
        """Nakreslí obrysový rámeček kolem každého vybraného objektu.

        boxes — seznam (x1, y1, x2, y2) z selection_handles.selection_boxes().
        Každý rámeček dostane tag 'sel_box' — clear() ho smaže.
        """
        cv = self.canvas
        try: cv.delete('sel_box')
        except Exception: pass
        PAD = 2
        for (x1, y1, x2, y2) in boxes:
            try:
                cv.create_rectangle(x1 - PAD, y1 - PAD, x2 + PAD, y2 + PAD,
                                    outline=color, fill='', width=1,
                                    dash=(3, 3), tags=('sel_box',))
            except Exception:
                pass

    def draw_rubber_band(self, x1: float, y1: float,
                         x2: float, y2: float, color='#06c'):
        """Nakreslí rubber-band obdélník při region výběru.

        Volá se opakovaně při on_move — vždy smaže předchozí a nakreslí nový.
        """
        cv = self.canvas
        try: cv.delete('rubber_band')
        except Exception: pass
        try:
            cv.create_rectangle(x1, y1, x2, y2,
                                 outline=color, fill='', width=1,
                                 dash=(4, 4), tags=('rubber_band',))
        except Exception:
            pass

    def clear_snap_marker(self):
        try: self.canvas.delete('snap_marker')
        except Exception: pass

    def draw_snap_marker(self, kind: str, x: float, y: float):
        """Nakreslí snap marker podle druhu snap bodu.

        line_end   -> zelený čtvereček
        line_mid   -> zelený trojúhelník (vrcholem nahoru)
        line_body  -> červený křížek
        hv_isect   -> zelený čtvereček (průsečík poloosy s objektem)
        """
        self.clear_snap_marker()
        cv = self.canvas
        if kind in ('line_end', 'hv_isect'):
            s = 5
            try:
                cv.create_rectangle(x - s, y - s, x + s, y + s,
                                    outline='#0a6', fill='', width=1,
                                    tags=('snap_marker',))
            except Exception:
                pass
        elif kind == 'line_mid':
            s = 6
            try:
                pts = [x, y - s, x + s, y + s, x - s, y + s]
                cv.create_polygon(pts, outline='#0a6', fill='',
                                  width=1, tags=('snap_marker',))
            except Exception:
                pass
        elif kind == 'line_body':
            s = 5
            try:
                cv.create_line(x - s, y - s, x + s, y + s,
                               fill='#c00', width=1, tags=('snap_marker',))
                cv.create_line(x + s, y - s, x - s, y + s,
                               fill='#c00', width=1, tags=('snap_marker',))
            except Exception:
                pass
