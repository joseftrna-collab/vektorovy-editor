# -*- coding: utf-8 -*-
from __future__ import annotations
import json
from pathlib import Path
from tkinter import filedialog, messagebox
from model.doc import Document

FILETYPES = [('VE document', '*.json'), ('All', '*.*')]


class FileService:
    """Zodpovědnost: načítání a ukládání dokumentu na disk.

    App volá save_as() a load() — FileService řeší dialog, soubor i chyby.
    Vrací True při úspěchu, False při zrušení nebo chybě.
    """

    def __init__(self, parent_window):
        self._parent = parent_window
        self.current_path: Path | None = None

    # ------------------------------------------------------------------
    def save_as(self, doc: Document) -> bool:
        """Uloží dokument — vždy se zeptá na cestu."""
        path_str = filedialog.asksaveasfilename(
            parent=self._parent,
            defaultextension='.json',
            filetypes=FILETYPES,
            initialfile=self.current_path.name if self.current_path else 'untitled.json',
        )
        if not path_str:
            return False
        return self._write(Path(path_str), doc)

    def save(self, doc: Document) -> bool:
        """Uloží dokument na stávající cestu; pokud není, zavolá save_as."""
        if self.current_path is None:
            return self.save_as(doc)
        return self._write(self.current_path, doc)

    def load(self, doc_callback) -> bool:
        """Zobrazí dialog, načte soubor a předá nový Document do doc_callback(doc).

        doc_callback je funkce App, která dokument přijme a překreslí plátno.
        Vrací True při úspěchu.
        """
        path_str = filedialog.askopenfilename(
            parent=self._parent,
            filetypes=FILETYPES,
        )
        if not path_str:
            return False
        path = Path(path_str)
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            doc = Document.from_json(data)
        except Exception as ex:
            messagebox.showerror('Chyba načítání', str(ex), parent=self._parent)
            return False
        self.current_path = path
        doc_callback(doc)
        return True

    # ------------------------------------------------------------------
    def _write(self, path: Path, doc: Document) -> bool:
        try:
            path.write_text(
                json.dumps(doc.to_json(), indent=2, ensure_ascii=False),
                encoding='utf-8',
            )
            self.current_path = path
            return True
        except Exception as ex:
            messagebox.showerror('Chyba uložení', str(ex), parent=self._parent)
            return False
