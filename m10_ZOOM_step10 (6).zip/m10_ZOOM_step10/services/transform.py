
# -*- coding: utf-8 -*-
from __future__ import annotations
from math import cos, sin
from core.types import LineSeg

def translate_line(ln: LineSeg, dx: float, dy: float) -> LineSeg:
    return LineSeg(ln.x1+dx, ln.y1+dy, ln.x2+dx, ln.y2+dy)

def rotate_point(x: float, y: float, cx: float, cy: float, a: float):
    ca, sa = cos(a), sin(a)
    xr, yr = x - cx, y - cy
    return cx + xr*ca - yr*sa, cy + xr*sa + yr*ca

def rotate_line(ln: LineSeg, cx: float, cy: float, a: float) -> LineSeg:
    x1,y1 = rotate_point(ln.x1, ln.y1, cx, cy, a)
    x2,y2 = rotate_point(ln.x2, ln.y2, cx, cy, a)
    return LineSeg(x1,y1,x2,y2)

def rotate_object(obj, cx: float, cy: float, a: float) -> None:
    """Otočí DrawObject in-place kolem (cx,cy) o úhel a (radiány).

    Pracuje přes get_state/apply_state — funguje pro libovolný DrawObject.
    Předpokládá, že stav obsahuje klíče 'x<n>'/'y<n>' (x1,y1,x2,y2,...).
    """
    state = obj.get_state()
    new_state = dict(state)
    # najdi dvojice xi/yi
    xs = sorted(k for k in state if k.startswith('x') and k[1:].isdigit())
    ys = sorted(k for k in state if k.startswith('y') and k[1:].isdigit())
    for xk, yk in zip(xs, ys):
        nx, ny = rotate_point(state[xk], state[yk], cx, cy, a)
        new_state[xk] = nx
        new_state[yk] = ny
    obj.apply_state(new_state)
