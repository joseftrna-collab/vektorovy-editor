# -*- coding: utf-8 -*-
"""DimService – dynamické kóty pro LineTool, styl AutoCAD.

Fáze 1 (bez start_pt): souřadnice (x, y) u kurzoru.
Fáze 2 (se start_pt) :
  • dash kóta délky  – kolmá kótovací čára souběžná s úsečkou, žlutý box
  • kóta úhlu        – přerušovaný oblouk od +X poloosy ke koncovému bodu,
                       modré písmo v žlutém rámečku uprostřed oblouku

Ruční zadávání:
  • LineTool volá dim.key_input(keysym, char) při každém stisku klávesy
  • aktivní pole (délka / úhel) se přepíná klávesou TAB
  • pole zobrazuje editovaný řetězec; Enter potvrdí, Escape zruší
  • při aktivním poli se pohyb myši ignoruje (lock_input=True)
"""
from __future__ import annotations
import math
import tkinter as tk

_TAG   = 'dyn_dim'
_BLUE  = '#88ccff'   # jednotná modrá pro vše
_BG_D  = ''          # bez podkladu
_BG_A  = ''          # bez podkladu
_FG_D  = _BLUE       # text délky
_FG_A  = _BLUE       # text úhlu
_FG_C  = '#e8e8e8'   # text souřadnic
_BG_C  = '#1e2433'
_ACC   = _BLUE       # čáry kóty délky
_ARC   = _BLUE       # oblouk úhlu
_FONT  = ('Consolas', 9)
_FONT_EDIT = ('Consolas', 10, 'bold')
_PAD   = 4
_OFF   = 16
_ARC_R_MIN = 20      # minimální poloměr oblouku úhlu (px)
_ARC_SEGS = 48       # počet segmentů oblouku


class DimService:
    def __init__(self, canvas: tk.Canvas):
        self.canvas = canvas
        # --- stav ručního zadávání ---
        self._active_field: str = 'length'   # 'length' | 'angle'
        self._buf_length: str = ''
        self._buf_angle:  str = ''
        self.lock_input: bool = False         # True = myš neaktualizuje preview
        # uložené souřadnice pro refresh při editaci
        self._last_x0: float = 0.0
        self._last_y0: float = 0.0
        self._last_lx: float = 0.0
        self._last_ly: float = 0.0
        # doc-space origin pro on_commit (canvas ≠ doc při zoom ≠ 1)
        self._doc_x0: float | None = None
        self._doc_y0: float | None = None
        # doc-space endpoint pro _refresh_locked_preview
        self._doc_last_lx: float = 0.0
        self._doc_last_ly: float = 0.0
        # callback volané Dim -> LineTool pro přepočet koncového bodu
        self.on_commit: 'function | None' = None   # fn(x0,y0,length,angle_deg)

    # ------------------------------------------------------------------
    # Veřejné API — stav
    # ------------------------------------------------------------------

    def reset_input(self):
        """Zruší editaci a vymaže buffery."""
        self._buf_length = ''
        self._buf_angle  = ''
        self.lock_input  = False
        self._active_field = 'length'
        self._doc_x0 = None
        self._doc_y0 = None

    def get_override(self) -> 'tuple[float|None, float|None]':
        """Vrátí (length_override, angle_override) nebo None pro každou složku."""
        L = A = None
        try:
            if self._buf_length: L = float(self._buf_length)
        except ValueError: pass
        try:
            if self._buf_angle:  A = float(self._buf_angle)
        except ValueError: pass
        return L, A

    # ------------------------------------------------------------------
    # Veřejné API — vstup klávesnice
    # ------------------------------------------------------------------

    def key_input(self, keysym: str, char: str) -> 'tuple[bool, bool]':
        """Zpracuje klávesu.

        Vrátí dvojici (consumed, refresh_preview):
          consumed        – True pokud událost spotřeboval DimService
          refresh_preview – True pokud má LineTool přepočítat preview úsečky
                            (pouze po TAB / Enter, ne po každé cifře)
        """
        ks = keysym.lower()

        # TAB přepíná pole — preview se přepočítá hned
        if ks == 'tab':
            self._active_field = 'angle' if self._active_field == 'length' else 'length'
            self.lock_input = True
            self._refresh_display()
            return True, True

        # číslice, tečka, mínus — jen zobrazí editovaný buffer, preview čeká
        if char and (char.isdigit() or char in ('.','-')):
            self.lock_input = True
            if self._active_field == 'length':
                self._buf_length += char
            else:
                self._buf_angle  += char
            self._refresh_display()
            return True, False   # ← preview se nemění

        # Backspace — také jen buffer, preview čeká
        if ks == 'backspace':
            if self._active_field == 'length' and self._buf_length:
                self._buf_length = self._buf_length[:-1]
                self._refresh_display()
                return True, False
            if self._active_field == 'angle' and self._buf_angle:
                self._buf_angle = self._buf_angle[:-1]
                self._refresh_display()
                return True, False

        # Enter — potvrď a aplikuj
        if ks == 'return':
            if self.on_commit and self.lock_input:
                L, A = self.get_override()
                if L is None or A is None:
                    # fallback: vektor v doc-space
                    dx = self._doc_last_lx - self._doc_x0
                    dy = self._doc_last_ly - self._doc_y0
                    if L is None:
                        L = math.hypot(dx, dy)
                    if A is None:
                        A = math.degrees(math.atan2(-dy, dx)) % 360
                # vždy předáváme doc-space origin
                self.on_commit(self._doc_x0, self._doc_y0, L, A)
            return True, False

        return False, False

    # ------------------------------------------------------------------
    # Veřejné API — kresba
    # ------------------------------------------------------------------

    def clear(self):
        try: self.canvas.delete(_TAG)
        except Exception: pass

    def show_cursor_coords(self, dx: float, dy: float,
                           cx: float | None = None, cy: float | None = None):
        """Fáze 1: souřadnice (x, y) u kurzoru.

        dx, dy  – doc-space hodnoty zobrazené v textu
        cx, cy  – canvas-space pozice pro umístění boxu (default = dx, dy)
        """
        self.clear()
        bx = cx if cx is not None else dx
        by = cy if cy is not None else dy
        text = f"({dx:.1f},  {dy:.1f})"
        self._draw_box(bx + _OFF, by - _OFF - 18, text, _FG_C, _BG_C)

    def show_length_angle(self, x0: float, y0: float,
                          lx: float, ly: float,
                          doc_x0: float = None, doc_y0: float = None,
                          doc_lx: float = None, doc_ly: float = None,
                          doc_length: float = None, doc_angle: float = None):
        """Fáze 2: kóta délky + kóta úhlu s obloukem.

        x0, y0, lx, ly  – canvas-space (pro kreslení)
        doc_x0, doc_y0  – doc-space origin (pro on_commit); fallback = x0, y0
        doc_lx, doc_ly  – doc-space endpoint (pro fallback L/A výpočet)
        doc_length       – doc-space délka pro zobrazení; fallback = canvas hypot
        doc_angle        – doc-space úhel pro zobrazení; fallback = canvas úhel
        """
        # ulož canvas coords pro refresh kreslení
        self._last_x0, self._last_y0 = x0, y0
        self._last_lx, self._last_ly = lx, ly
        # ulož doc-space pro on_commit a fallback výpočty
        self._doc_x0 = doc_x0 if doc_x0 is not None else x0
        self._doc_y0 = doc_y0 if doc_y0 is not None else y0
        self._doc_last_lx = doc_lx if doc_lx is not None else lx
        self._doc_last_ly = doc_ly if doc_ly is not None else ly

        dx = lx - x0; dy = ly - y0
        # zobrazená délka: preferuj doc-space hodnotu
        base_length = doc_length if doc_length is not None else math.hypot(dx, dy)
        base_angle  = doc_angle  if doc_angle  is not None else math.degrees(math.atan2(-dy, dx)) % 360

        # override z bufferu
        L_ov, A_ov = self.get_override()
        disp_length = L_ov if L_ov is not None else base_length
        disp_angle  = A_ov if A_ov is not None else base_angle

        self.clear()
        self._draw_length_dim(x0, y0, lx, ly, disp_length)
        self._draw_angle_dim(x0, y0, lx, ly, disp_angle)

    # ------------------------------------------------------------------
    # Interní – refresh při editaci (bez pohybu myši)
    # ------------------------------------------------------------------

    def _refresh_display(self):
        if self._last_x0 == self._last_lx and self._last_y0 == self._last_ly:
            return
        self.show_length_angle(self._last_x0, self._last_y0,
                                self._last_lx, self._last_ly,
                                doc_x0=self._doc_x0, doc_y0=self._doc_y0,
                                doc_lx=self._doc_last_lx, doc_ly=self._doc_last_ly)

    # ------------------------------------------------------------------
    # Interní kresba
    # ------------------------------------------------------------------

    def _draw_box(self, bx: float, by: float, text: str,
                  fg: str, bg: str, editing: bool = False) -> tuple:
        cv = self.canvas
        font = _FONT_EDIT if editing else _FONT
        tid = cv.create_text(bx, by, text=text, font=font,
                             fill=fg, anchor='nw', tags=(_TAG,))
        bb = cv.bbox(tid)
        if not bb:
            return (bx, by, bx + 60, by + 16)
        tx1, ty1, tx2, ty2 = bb
        rx1 = tx1 - _PAD; ry1 = ty1 - _PAD
        rx2 = tx2 + _PAD; ry2 = ty2 + _PAD
        lw = 2 if editing else 1
        # bg=='' znamená průhledný podklad (bez fill)
        rect_kw = dict(outline=fg, width=lw, tags=(_TAG,))
        if bg:
            rect_kw['fill'] = bg
        cv.create_rectangle(rx1, ry1, rx2, ry2, **rect_kw)
        cv.tag_raise(tid)
        return (rx1, ry1, rx2, ry2)

    def _draw_length_dim(self, x0: float, y0: float,
                         x1: float, y1: float, length: float):
        cv = self.canvas
        dx = x1 - x0; dy = y1 - y0
        hyp = math.hypot(dx, dy) or 1.0
        nx = -dy / hyp; ny = dx / hyp
        off = max(12.0, min(24.0, hyp * 0.15))

        # kóta délky je na OPAČNÉ straně než oblouk úhlu (ten jde doprava/nahoru)
        lx0 = x0 - nx * off; ly0 = y0 - ny * off
        lx1 = x1 - nx * off; ly1 = y1 - ny * off

        # prodloužení
        cv.create_line(x0, y0, lx0, ly0, fill=_ACC, dash=(2, 3),
                       width=1, tags=(_TAG,))
        cv.create_line(x1, y1, lx1, ly1, fill=_ACC, dash=(2, 3),
                       width=1, tags=(_TAG,))
        # kótovací čára
        cv.create_line(lx0, ly0, lx1, ly1, fill=_ACC, dash=(4, 3),
                       width=1, tags=(_TAG,))

        mx = (lx0 + lx1) / 2; my = (ly0 + ly1) / 2
        editing = (self._active_field == 'length' and self.lock_input)
        buf = self._buf_length
        disp = (buf + '|') if editing else f"{length:.2f}"
        self._draw_box(mx - 26, my - 9, disp, _FG_D, _BG_D, editing)

    def _draw_angle_dim(self, x0: float, y0: float,
                        x1: float, y1: float, angle_deg: float):
        """Přerušovaný oblouk od +X osy ke koncovému bodu; popis uprostřed."""
        cv = self.canvas
        line_len = math.hypot(x1 - x0, y1 - y0)
        r = max(_ARC_R_MIN, line_len)  # oblouk prochází koncovým bodem

        # úhel v rad (canvas: y roste dolů => negate)
        a_rad = math.radians(angle_deg)   # CCW od +X

        # bodů oblouku od 0 do a_rad (canvas: CW je kladný y-down)
        # v canvas souřadnicích: bod na oblouku = (x0 + r*cos(t), y0 - r*sin(t))
        segs = max(6, int(abs(angle_deg) / 3))
        pts = []
        for i in range(segs + 1):
            t = a_rad * i / segs
            pts.append(x0 + r * math.cos(t))
            pts.append(y0 - r * math.sin(t))   # y-down konvence

        # polooska +X (čárkovaná)
        cv.create_line(x0, y0, x0 + r + 8, y0, fill=_ARC,
                       dash=(3, 3), width=1, tags=(_TAG,))

        # oblouk jako série krátkých segmentů (dash efekt)
        if len(pts) >= 4:
            cv.create_line(*pts, fill=_ARC, dash=(4, 3),
                           width=1, smooth=False, tags=(_TAG,))

        # popis uprostřed oblouku — 60 % poloměru (uvnitř, čitelné)
        mid_t = a_rad / 2
        label_r = max(r * 0.6, r - 20)
        lx = x0 + label_r * math.cos(mid_t)
        ly = y0 - label_r * math.sin(mid_t)

        editing = (self._active_field == 'angle' and self.lock_input)
        buf = self._buf_angle
        disp = (buf + '|') if editing else f"{angle_deg:.1f}°"
        # anchor: umísti box středem na lx, ly
        tw = len(disp) * 7 + _PAD * 2
        self._draw_box(lx - tw / 2, ly - 9, disp, _FG_A, _BG_A, editing)
