
# -*- coding: utf-8 -*-
from __future__ import annotations
from typing import Optional, Tuple

def hv_lock_project(base_x: float, base_y: float,
                    mx: float, my: float,
                    hv_state: Optional[str],
                    band_in: float, band_out: float,
                    guides_on: bool, half_axes_on: bool,
                    draw_half_axis=None, clear_half_axis=None) -> Tuple[float, float, Optional[str]]:
    dx, dy = mx - base_x, my - base_y
    hv = hv_state
    if hv is None:
        if abs(dy) <= band_in:
            hv = 'h'
        elif abs(dx) <= band_in:
            hv = 'v'
    elif hv == 'h' and abs(dy) >= band_out:
        hv = None
    elif hv == 'v' and abs(dx) >= band_out:
        hv = None
    if hv is not None and guides_on and half_axes_on:
        if draw_half_axis:
            draw_half_axis(base_x, base_y, mx, my, hv)
        if hv == 'h':
            my = base_y
        else:
            mx = base_x
    else:
        if clear_half_axis:
            clear_half_axis()
    return mx, my, hv
