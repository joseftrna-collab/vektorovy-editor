# -*- coding: utf-8 -*-
"""Viewport – transformace mezi souřadnicemi dokumentu a plátna.

Konvence:
    canvas_x = doc_x * scale + pan_x
    canvas_y = doc_y * scale + pan_y

    doc_x = (canvas_x - pan_x) / scale
    doc_y = (canvas_y - pan_y) / scale

Používá se všude, kde se přechází mezi doc-space a canvas-space:
  • kreslení objektů  → to_canvas()
  • vstupy myši       → to_doc()
  • zoom na bod       → zoom_at()
"""
from __future__ import annotations

_SCALE_MIN = 0.05
_SCALE_MAX = 50.0
_ZOOM_STEP = 1.25   # faktor jednoho kroku kolečka


class Viewport:
    def __init__(self):
        self.scale: float = 1.0
        self.pan_x: float = 0.0
        self.pan_y: float = 0.0

    # ------------------------------------------------------------------
    # Transformace
    # ------------------------------------------------------------------

    def to_canvas(self, dx: float, dy: float) -> tuple[float, float]:
        """Doc-space → canvas-space."""
        return dx * self.scale + self.pan_x, dy * self.scale + self.pan_y

    def to_doc(self, cx: float, cy: float) -> tuple[float, float]:
        """Canvas-space → doc-space."""
        return (cx - self.pan_x) / self.scale, (cy - self.pan_y) / self.scale

    def scale_to_canvas(self, d: float) -> float:
        """Délka v doc-space → délka v canvas-space."""
        return d * self.scale

    def scale_to_doc(self, d: float) -> float:
        """Délka v canvas-space → délka v doc-space."""
        return d / self.scale

    # ------------------------------------------------------------------
    # Zoom
    # ------------------------------------------------------------------

    def zoom_at(self, cx: float, cy: float, factor: float) -> None:
        """Zoom s pevným bodem na pozici kurzoru (cx, cy) v canvas-space."""
        new_scale = max(_SCALE_MIN, min(_SCALE_MAX, self.scale * factor))
        if new_scale == self.scale:
            return
        # zachovej doc-point pod kurzorem
        self.pan_x = cx - (cx - self.pan_x) * (new_scale / self.scale)
        self.pan_y = cy - (cy - self.pan_y) * (new_scale / self.scale)
        self.scale = new_scale

    def zoom_step(self, cx: float, cy: float, direction: int) -> None:
        """direction: +1 = přiblížit, -1 = oddálit."""
        factor = _ZOOM_STEP if direction > 0 else 1.0 / _ZOOM_STEP
        self.zoom_at(cx, cy, factor)

    def reset(self) -> None:
        self.scale = 1.0
        self.pan_x = 0.0
        self.pan_y = 0.0

    # ------------------------------------------------------------------
    # Fit
    # ------------------------------------------------------------------

    def fit(self, lines, canvas_w: float, canvas_h: float,
            margin: float = 40.0) -> None:
        """Zoom + pan tak, aby všechny úsečky byly vidět."""
        if not lines:
            self.reset()
            return
        xs = [v for l in lines for v in (l.x1, l.x2)]
        ys = [v for l in lines for v in (l.y1, l.y2)]
        x_min, x_max = min(xs), max(xs)
        y_min, y_max = min(ys), max(ys)
        w = x_max - x_min or 1.0
        h = y_max - y_min or 1.0
        sx = (canvas_w - 2 * margin) / w
        sy = (canvas_h - 2 * margin) / h
        self.scale = max(_SCALE_MIN, min(_SCALE_MAX, min(sx, sy)))
        self.pan_x = margin - x_min * self.scale + (canvas_w - 2 * margin - w * self.scale) / 2
        self.pan_y = margin - y_min * self.scale + (canvas_h - 2 * margin - h * self.scale) / 2
