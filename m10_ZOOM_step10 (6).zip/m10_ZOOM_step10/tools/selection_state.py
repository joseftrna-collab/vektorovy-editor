# -*- coding: utf-8 -*-
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Tuple, Set


@dataclass
class SelectionState:
    """Čistý datový objekt — co je vybráno a jaký je stav interakce.

    Neobsahuje žádnou logiku ani reference na GUI.
    SelectionTool ho vlastní a mutuje; ostatní moduly ho pouze čtou.
    """

    # --- výběr ---
    objects: Set = field(default_factory=set)
    # set[DrawObject] — reference na objekty, nikoli indexy

    # --- pivot pro rotaci ---
    pivot: Optional[Tuple[float, float]] = None
    # None → pivot se počítá jako střed group_bbox za běhu

    # --- region výběr (klik-klik) ---
    region_anchor: Optional[Tuple[float, float]] = None
    # Souřadnice prvního kliku; None = region výběr neprobíhá

    # --- snapshot před dragem (pro undo) ---
    drag_origin: Optional[Tuple[float, float]] = None
    # Souřadnice myši při začátku dragu

    orig_coords: dict = field(default_factory=dict)
    # {DrawObject: (x1, y1, x2, y2)} — snapshot před dragem

    # --- příznaky módu ---
    is_copy_drag: bool = False
    rotate_mode: bool = False
    rotate_ref_angle: Optional[float] = None

    # --- aktivní handle ---
    active_handle: Optional[str] = None
    # 'mid' | 'corner_tl' | 'corner_tr' | 'corner_bl' | 'corner_br' | 'pivot'

    # ------------------------------------------------------------------
    # Pomocné metody — žádná geometrie, jen správa dat
    # ------------------------------------------------------------------

    def clear_selection(self) -> None:
        self.objects.clear()
        self.pivot = None

    def clear_drag(self) -> None:
        self.drag_origin = None
        self.orig_coords.clear()
        self.active_handle = None
        self.is_copy_drag = False

    def clear_region(self) -> None:
        self.region_anchor = None

    def snapshot_coords(self) -> None:
        """Uloží stav všech vybraných objektů (get_state)."""
        self.orig_coords = {}
        for obj in self.objects:
            self.orig_coords[obj] = obj.get_state()

    def restore_coords(self) -> None:
        """Obnoví stav ze snapshotu (apply_state)."""
        for obj, state in self.orig_coords.items():
            obj.apply_state(state)

    @property
    def has_selection(self) -> bool:
        return bool(self.objects)

    @property
    def is_dragging(self) -> bool:
        return self.drag_origin is not None

    @property
    def in_region_select(self) -> bool:
        return self.region_anchor is not None
