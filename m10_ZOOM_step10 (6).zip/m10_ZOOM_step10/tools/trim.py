# -*- coding: utf-8 -*-
from tools.base import ToolBase
from services.geom_split import intersect, split_line
from core.commands import TrimCmd

_TOL_D2 = 36   # canvas-space hit tolerance (6px)^2 — stejné jako step7c

class TrimTool(ToolBase):
    def __init__(self, app):
        super().__init__(app)
        self.hover = None        # index do doc.objects
        self._hover_seg = None   # segment ke smazání (LineSeg)

    def cancel(self):
        self.hover = None
        self._hover_seg = None
        self.app.overlays.clear()
        self.app.view.clear_preview()

    def on_move(self, x, y, e=None):
        vp = self.app.viewport
        # Pracujeme v doc-space (x,y jsou doc coords), ale tolerance
        # z step7c byla v canvas-space (d < 36 px^2).
        # Převedeme toleranci do doc-space.
        tol_doc = vp.scale_to_doc(6.0)   # 6 canvas px → doc units
        tol_doc2 = tol_doc * tol_doc

        lines = self.app.doc.objects   # funguje pro všechny DrawObject
        best = None
        di = 1e9
        for i, ln in enumerate(lines):
            d = ln.distance_to(x, y)
            d2 = d * d
            if d2 < di and d2 <= tol_doc2:
                di = d2
                best = i

        self.hover = best
        self._hover_seg = None
        self.app.overlays.clear()
        self.app.view.clear_preview()
        if best is None:
            return

        ln = lines[best]
        pts = []
        for j, other in enumerate(lines):
            if j == best:
                continue
            p = intersect(ln, other)
            if p:
                pts.append(p)
        segs = split_line(ln, pts)

        # najdi segment nejblíže kurzoru (v doc-space)
        best_seg = None
        best_d2 = 1e18
        for s in segs:
            d2 = s.distance_to(x, y) ** 2
            if d2 < best_d2:
                best_d2 = d2
                best_seg = s

        if best_seg:
            self._hover_seg = best_seg
            # preview červeně v canvas-space
            cx1, cy1 = vp.to_canvas(best_seg.x1, best_seg.y1)
            cx2, cy2 = vp.to_canvas(best_seg.x2, best_seg.y2)
            self.app.overlays.draw_trim_preview(cx1, cy1, cx2, cy2)

    def on_down(self, x, y, e=None):
        if self.hover is None or self._hover_seg is None:
            return
        lines = self.app.doc.objects
        if self.hover >= len(lines):
            return
        ln = lines[self.hover]
        pts = []
        for j, other in enumerate(lines):
            if j == self.hover:
                continue
            p = intersect(ln, other)
            if p:
                pts.append(p)
        segs = split_line(ln, pts)
        hover = self._hover_seg
        keep = [s for s in segs if not (
            abs(s.x1 - hover.x1) < 1e-6 and abs(s.y1 - hover.y1) < 1e-6 and
            abs(s.x2 - hover.x2) < 1e-6 and abs(s.y2 - hover.y2) < 1e-6
        )]
        cmd = TrimCmd(self.app.doc, ln, keep, self.hover)
        self.app.history.push(cmd)
        self.hover = None
        self._hover_seg = None
        self.app.overlays.clear()
        self.app.view.clear_preview()
        self.app.view.clear()
        vp = self.app.viewport
        for obj in self.app.doc.objects:
            obj.render(self.app.view, vp)
