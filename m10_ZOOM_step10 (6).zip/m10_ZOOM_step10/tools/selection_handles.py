# -*- coding: utf-8 -*-
from __future__ import annotations
from typing import List, Optional, Set, Tuple, NamedTuple


# ---------------------------------------------------------------------------
# Datový typ Handle
# ---------------------------------------------------------------------------

class Handle(NamedTuple):
    name: str           # 'mid' | 'corner_tl' | 'corner_tr' | 'corner_bl' | 'corner_br' | 'pivot'
    x: float
    y: float


# ---------------------------------------------------------------------------
# Bounding box
# ---------------------------------------------------------------------------

def object_bbox(obj) -> Tuple[float, float, float, float]:
    """Vrátí (x_min, y_min, x_max, y_max) jednoho objektu."""
    return obj.bbox()


def group_bbox(objects) -> Optional[Tuple[float, float, float, float]]:
    """Vrátí union bbox všech objektů, nebo None pro prázdnou množinu."""
    if not objects:
        return None
    xs1, ys1, xs2, ys2 = [], [], [], []
    for obj in objects:
        x1, y1, x2, y2 = obj.bbox()
        xs1.append(x1); ys1.append(y1)
        xs2.append(x2); ys2.append(y2)
    return (min(xs1), min(ys1), max(xs2), max(ys2))


def bbox_center(bbox: Tuple[float, float, float, float]) -> Tuple[float, float]:
    x1, y1, x2, y2 = bbox
    return ((x1 + x2) / 2.0, (y1 + y2) / 2.0)


# ---------------------------------------------------------------------------
# Handles skupiny
# ---------------------------------------------------------------------------

def group_handles(objects, pivot: Optional[Tuple[float, float]] = None) -> List[Handle]:
    """Vrátí 5 + 1 handleů: 4 rohy bboxu, střed a pivot.

    Pořadí: corner_tl, corner_tr, corner_br, corner_bl, mid, pivot.
    Pivot se počítá jako střed bbox, pokud není explicitně zadán.
    """
    bbox = group_bbox(objects)
    if bbox is None:
        return []
    x1, y1, x2, y2 = bbox
    cx, cy = bbox_center(bbox)
    px, py = pivot if pivot is not None else (cx, cy)
    return [
        Handle('corner_tl', x1, y1),
        Handle('corner_tr', x2, y1),
        Handle('corner_br', x2, y2),
        Handle('corner_bl', x1, y2),
        Handle('mid',       cx, cy),
        Handle('pivot',     px, py),
    ]


def hit_handle(handles: List[Handle], x: float, y: float, tol: float = 6.0) -> Optional[Handle]:
    """Vrátí první handle, jehož plocha obsahuje bod (x, y), nebo None."""
    s = tol / 2.0 + 2.0
    for h in handles:
        if (h.x - s) <= x <= (h.x + s) and (h.y - s) <= y <= (h.y + s):
            return h
    return None


# ---------------------------------------------------------------------------
# Region výběr
# ---------------------------------------------------------------------------

def objects_in_region(
    objects,
    rx1: float, ry1: float,
    rx2: float, ry2: float,
    mode: str = 'auto',
) -> Set:
    """Vrátí množinu objektů uvnitř nebo křížících region.

    mode:
      'inside'   — pouze objekty celé uvnitř regionu
      'crossing' — objekty, jejichž bbox se kříží s regionem
      'auto'     — inside pokud rx1 < rx2, crossing pokud rx1 > rx2
                   (CAD konvence: zleva=inside, zprava=crossing)
    """
    # Normalizace souřadnic regionu
    left   = min(rx1, rx2)
    right  = max(rx1, rx2)
    top    = min(ry1, ry2)
    bottom = max(ry1, ry2)

    if mode == 'auto':
        effective = 'inside' if rx1 <= rx2 else 'crossing'
    else:
        effective = mode

    result = set()
    for obj in objects:
        ox1, oy1, ox2, oy2 = obj.bbox()
        if effective == 'inside':
            if ox1 >= left and oy1 >= top and ox2 <= right and oy2 <= bottom:
                result.add(obj)
        else:  # crossing
            # Objekty se nekříží pouze pokud jsou zcela mimo
            if not (ox2 < left or ox1 > right or oy2 < top or oy1 > bottom):
                result.add(obj)
    return result


# ---------------------------------------------------------------------------
# Boxy kolem jednotlivých objektů (vizuální feedback)
# ---------------------------------------------------------------------------

def selection_boxes(objects) -> List[Tuple[float, float, float, float]]:
    """Vrátí seznam (x1, y1, x2, y2) pro každý vybraný objekt zvlášť."""
    return [obj.bbox() for obj in objects]
