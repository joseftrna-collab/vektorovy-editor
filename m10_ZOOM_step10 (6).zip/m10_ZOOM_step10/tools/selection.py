# -*- coding: utf-8 -*-
from __future__ import annotations
from math import atan2, pi

from tools.base import ToolBase
from tools.selection_state import SelectionState
from tools.selection_handles import (
    group_handles, hit_handle, objects_in_region,
    selection_boxes, group_bbox, bbox_center,
)
from services.hv import hv_lock_project
from services.transform import rotate_line
from core.commands import (
    MoveSelectionCmd, CopySelectionCmd,
    RotateSelectionCmd, DeleteSelectionCmd,
    TransformLineCmd, TransformCmd,
)
from core import tracer

_SHIFT_MASK = 0x0001
_CTRL_MASK  = 0x0004

def _has(mod, mask):
    try:    return bool(mod & mask)
    except Exception: return False

def _nearest_object(objects, x, y, tol):
    """Vrátí nejbližší objekt do vzdálenosti tol (doc-space), nebo None."""
    best, best_d = None, None
    for obj in objects:
        d = obj.distance_to(x, y)
        if d <= tol and (best_d is None or d < best_d):
            best, best_d = obj, d
    return best

class SelectionTool(ToolBase):

    def __init__(self, app):
        super().__init__(app)
        self._st = SelectionState()
        self._hv_state = None           # pro stretch end1/end2
        self._last_endpoint_pos = None  # (kind, x, y) pro ghost→commit

    # ------------------------------------------------------------------
    # Viewport helper
    # ------------------------------------------------------------------

    def _vp(self):
        return self.app.viewport

    # ------------------------------------------------------------------
    # Veřejné metody (volané z AppUI / App)
    # ------------------------------------------------------------------

    def toggle_rotate_mode(self):
        if not self._st.has_selection:
            return
        self._st.rotate_mode = not self._st.rotate_mode
        self._st.clear_drag()
        self._hv_state = None
        if self._st.rotate_mode:
            obj = next(iter(self._st.objects))
            px, py = self._pivot_xy()
            ep = obj.endpoints(); self._st.rotate_ref_angle = atan2(ep[-1][1] - py, ep[-1][0] - px)
        else:
            self.app.view.clear_preview()
        self._show()

    def delete_selection(self):
        if not self._st.has_selection:
            return
        cmd = DeleteSelectionCmd(self.app.doc, list(self._st.objects))
        self.app.history.push(cmd)
        self._st.clear_selection()
        self._redraw()

    def cancel(self):
        tracer.trace('TOOL', 'sel.cancel')
        self._st = SelectionState()
        self._hv_state = None
        self._last_endpoint_pos = None
        self.app.snap.reset()
        self.app.snap_marker.clear()
        self.app.ldo.clear_half_axis()
        self.app.view.clear_preview()
        self.app.view.clear_ghost()
        self._redraw()

    # ------------------------------------------------------------------
    # Události
    # ------------------------------------------------------------------

    def on_right(self, x, y, e=None):
        mx, my = self.app.snap.apply(x, y) if self.app.state.snap_enabled else (x, y)
        self._st.pivot = (mx, my)
        self._show()

    def on_down(self, x, y, e=None):
        tracer.trace('TOOL', 'sel.on_down', x=x, y=y)
        if self.app.state.trim_mode:
            return self.app.trim_tool.on_down(x, y, e)

        # --- ROTATE MODE: klik potvrdí rotaci ---
        if self._st.rotate_mode and self._st.has_selection:
            self._confirm_rotate(x, y, e)
            return

        handles = group_handles(self._st.objects, self._st.pivot)
        tol_doc = self._vp().scale_to_doc(8.0)
        hit = hit_handle(handles, x, y, tol=tol_doc)

        if hit is not None:
            self._start_drag(hit, x, y, e)
            return

        # --- klik mimo handle ---
        if self._st.in_region_select:
            # druhý klik — uzavři region
            self._finish_region(x, y, e)
        else:
            obj = _nearest_object(self.app.doc.objects, x, y,
                                  self._vp().scale_to_doc(self.app.state.select_tol_px))
            if obj is not None:
                shift = _has(getattr(e, 'state', 0), _SHIFT_MASK)
                if shift:
                    if obj in self._st.objects:
                        self._st.objects.discard(obj)
                    else:
                        self._st.objects.add(obj)
                else:
                    self._st.objects = {obj}
                self._st.pivot = None
                self._show()
            else:
                # první klik do prázdna — začni region výběr
                self._st.clear_selection()
                self._st.region_anchor = (x, y)
                self._show()

        try: self.app.ui.refresh_status()
        except Exception: pass

    def on_move(self, x, y, e=None):
        tracer.trace('MOVE', 'sel.on_move', x=x, y=y)
        if self.app.state.trim_mode:
            return self.app.trim_tool.on_move(x, y, e)

        # --- snap marker (vždy, pokud neni drag a neni rotate) ---
        if not self._st.is_dragging and not self._st.rotate_mode and not self._st.in_region_select:
            snap_res = self.app.snap.find(x, y) if self.app.state.snap_enabled else None
            if snap_res is not None:
                tracer.trace('SNAP', 'find', kind=snap_res.kind,
                             x=round(snap_res.x,1), y=round(snap_res.y,1))
                self.app.snap_marker.propose(snap_res.kind, snap_res.x, snap_res.y)
            self.app.snap_marker.flush()

        # --- ROTATE preview ---
        if self._st.rotate_mode and self._st.has_selection:
            self._preview_rotate(x, y, e)
            return

        # --- rubber-band ---
        if self._st.in_region_select:
            ax, ay = self._st.region_anchor
            vp = self._vp()
            cax, cay = vp.to_canvas(ax, ay)
            cx,  cy  = vp.to_canvas(x, y)
            self.app.overlays.draw_rubber_band(cax, cay, cx, cy)
            return

        if not self._st.is_dragging:
            return

        kind = self._st.active_handle
        if kind == 'pivot':
            self._drag_pivot(x, y)
        elif kind in ('end1', 'end2'):
            self._drag_endpoint(kind, x, y, e)
        elif kind in ('mid', 'corner_tl', 'corner_tr', 'corner_br', 'corner_bl'):
            self._drag_move(x, y, e)

    def on_up(self, x, y, e=None):
        if not self._st.is_dragging:
            return
        kind = self._st.active_handle
        if kind in ('end1', 'end2'):
            self._finish_endpoint_drag()
        elif kind in ('mid', 'corner_tl', 'corner_tr', 'corner_br', 'corner_bl'):
            self._finish_move_drag(x, y, e)
        self._st.clear_drag()
        self._hv_state = None
        self.app.ldo.clear_half_axis()
        self.app.view.clear_ghost()
        self._redraw()

    # ------------------------------------------------------------------
    # Drag — zahájení
    # ------------------------------------------------------------------

    def _start_drag(self, hit, x, y, e):
        self._st.active_handle = hit.name
        self._st.drag_origin   = (x, y)

        if hit.name == 'pivot':
            return

        if hit.name in ('end1', 'end2'):
            if len(self._st.objects) == 1:
                self._st.snapshot_coords()
                self._hv_state = None
            return

        # mid / corner — move nebo copy
        ctrl = _has(getattr(e, 'state', 0), _CTRL_MASK)
        self._st.is_copy_drag = ctrl
        self._st.snapshot_coords()
        try: self.app.ui.refresh_status()
        except Exception: pass

    # ------------------------------------------------------------------
    # Drag — pohyb
    # ------------------------------------------------------------------

    def _drag_pivot(self, x, y):
        mx, my = (self.app.snap.apply_for_move(x, y)
                  if hasattr(self.app.snap, 'apply_for_move') else (x, y))
        self._st.pivot = (mx, my)
        self._show()

    def _drag_endpoint(self, kind, x, y, e):
        if len(self._st.objects) != 1:
            return
        ln = next(iter(self._st.objects))
        pts = ln.endpoints()
        bx, by = pts[1] if kind == 'end1' else pts[0]
        mx, my = x, y
        if self.app.state.snap_enabled:
            mx, my, self._hv_state = hv_lock_project(
                bx, by, mx, my, self._hv_state,
                self.app.state.hv_band_in_px, self.app.state.hv_band_out_px,
                self.app.cfg.flags.AXIS_GUIDES, self.app.cfg.flags.HALF_AXES,
                self.app.ldo.half_axis, self.app.ldo.clear_half_axis,
            )
        else:
            self._hv_state = None
            self.app.ldo.clear_half_axis()
        # Ghost: ukáže novou polohu úsečky, originál zůstává nedotčen
        os = self._st.orig_coords[ln]
        ox1, oy1, ox2, oy2 = os['x1'], os['y1'], os['x2'], os['y2']
        if kind == 'end1':
            gx1, gy1, gx2, gy2 = mx, my, ox2, oy2
        else:
            gx1, gy1, gx2, gy2 = ox1, oy1, mx, my
        self._last_endpoint_pos = (kind, mx, my)
        vp = self._vp()
        cgx1, cgy1 = vp.to_canvas(gx1, gy1)
        cgx2, cgy2 = vp.to_canvas(gx2, gy2)
        self.app.view.clear_ghost()
        self.app.view.draw_ghost(cgx1, cgy1, cgx2, cgy2)
        self._show()

    def _drag_move(self, x, y, e):
        ox, oy = self._st.drag_origin
        mx, my = (self.app.snap.apply_for_move(x, y)
                  if hasattr(self.app.snap, 'apply_for_move') else (x, y))
        dx, dy = mx - ox, my - oy

        if _has(getattr(e, 'state', 0), _SHIFT_MASK):
            bbox = group_bbox(self._st.objects)
            if bbox:
                cx, cy = bbox_center(bbox)
                px, py, _ = hv_lock_project(
                    cx, cy, cx + dx, cy + dy, None,
                    self.app.state.hv_band_in_px, self.app.state.hv_band_out_px,
                    False, False, None, None,
                )
                dx, dy = px - cx, py - cy

        # Ghost: kreslíme náhled na nové pozici, originály zůstávají nedotčeny
        vp = self._vp()
        self.app.view.clear_ghost()
        for obj, st in self._st.orig_coords.items():
            x1, y1, x2, y2 = st['x1'], st['y1'], st['x2'], st['y2']
            cx1, cy1 = vp.to_canvas(x1 + dx, y1 + dy)
            cx2, cy2 = vp.to_canvas(x2 + dx, y2 + dy)
            self.app.view.draw_ghost(cx1, cy1, cx2, cy2)
        self._show()

    # ------------------------------------------------------------------
    # Drag — ukončení
    # ------------------------------------------------------------------

    def _finish_endpoint_drag(self):
        if len(self._st.objects) != 1 or not self._st.orig_coords:
            return
        obj = next(iter(self._st.objects))
        old = self._st.orig_coords.get(obj)
        if old is None:
            return
        mx_ghost = getattr(self, '_last_endpoint_pos', None)
        if mx_ghost is None:
            return
        kind, mx, my = mx_ghost
        new_state = dict(old)
        if kind == 'end1':
            new_state['x1'], new_state['y1'] = mx, my
        else:
            new_state['x2'], new_state['y2'] = mx, my
        if new_state != old:
            obj.apply_state(new_state)
            cmd = TransformCmd(obj, old, new_state)
            self.app.history.push(cmd)
        self._last_endpoint_pos = None

    def _finish_move_drag(self, x, y, e):
        if not self._st.orig_coords:
            return
        ox, oy = self._st.drag_origin
        mx, my = (self.app.snap.apply_for_move(x, y)
                  if hasattr(self.app.snap, 'apply_for_move') else (x, y))
        dx, dy = mx - ox, my - oy
        if dx == 0 and dy == 0:
            return
        if self._st.is_copy_drag:
            # Vytvoří kopie posunuté o (dx, dy) a přidá je do doc
            cmd = CopySelectionCmd(self.app.doc, list(self._st.objects), dx, dy)
            self.app.history.push(cmd)
            # Po commitu vybereme kopie
            self._st.objects = set(cmd.copies)
            self._st.pivot = None
        else:
            # Přesune originály — souřadnice nebyly živě měněny, push() je aplikuje
            cmd = MoveSelectionCmd(
                list(self._st.objects),
                self._st.orig_coords,
                dx, dy,
            )
            self.app.history.push(cmd)

    # ------------------------------------------------------------------
    # Rotace
    # ------------------------------------------------------------------

    def _preview_rotate(self, x, y, e):
        px, py = self._pivot_xy()
        ang_cur = atan2(y - py, x - px)
        da = ang_cur - (self._st.rotate_ref_angle or 0.0)
        if _has(getattr(e, 'state', 0), _SHIFT_MASK):
            step = pi / 12.0
            da = round(da / step) * step
        vp = self._vp()
        self.app.view.clear_preview()
        from services.transform import rotate_object
        import copy as _copy
        for obj in self._st.objects:
            ghost = _copy.copy(obj)
            rotate_object(ghost, px, py, da)
            ghost.render_preview(self.app.view, vp)

    def _confirm_rotate(self, x, y, e):
        px, py = self._pivot_xy()
        ang_cur = atan2(y - py, x - px)
        da = ang_cur - (self._st.rotate_ref_angle or 0.0)
        if _has(getattr(e, 'state', 0), _SHIFT_MASK):
            step = pi / 12.0
            da = round(da / step) * step
        old_coords = {obj: obj.get_state()
                      for obj in self._st.objects}
        cmd = RotateSelectionCmd(list(self._st.objects), old_coords, px, py, da)
        self.app.history.push(cmd)
        tracer.trace('CMD', 'RotateSelection', n=len(self._st.objects), da=round(da,3))
        self._st.rotate_mode = False
        self._st.rotate_ref_angle = None
        self.app.view.clear_preview()
        self._redraw()

    # ------------------------------------------------------------------
    # Region výběr
    # ------------------------------------------------------------------

    def _finish_region(self, x, y, e):
        ax, ay = self._st.region_anchor
        self._st.clear_region()
        self.app.overlays.clear()
        sel = objects_in_region(self.app.doc.lines, ax, ay, x, y, mode='auto')
        shift = _has(getattr(e, 'state', 0), _SHIFT_MASK)
        if shift:
            self._st.objects |= sel
        else:
            self._st.objects = sel
        self._st.pivot = None
        self._show()

    # ------------------------------------------------------------------
    # Interní pomocné metody
    # ------------------------------------------------------------------

    def _pivot_xy(self):
        if self._st.pivot is not None:
            return self._st.pivot
        bbox = group_bbox(self._st.objects)
        if bbox:
            return bbox_center(bbox)
        return (0.0, 0.0)

    def _show(self):
        self.app.overlays.clear()
        if not self._st.has_selection:
            return
        vp = self._vp()
        handles_doc = group_handles(self._st.objects, self._st.pivot)
        # transformuj do canvas-space
        from tools.selection_handles import Handle
        handles_canvas = [
            Handle(h.name, *vp.to_canvas(h.x, h.y))
            for h in handles_doc
        ]
        self.app.overlays.draw_group_handles(handles_canvas)

    def _redraw(self):
        vp = self._vp()
        self.app.view.clear()
        self.app.overlays.clear()
        for obj in self.app.doc.objects:
            obj.render(self.app.view, vp)
        self._show()
        try: self.app.ui.refresh_status()
        except Exception: pass
