# -*- coding: utf-8 -*-
from __future__ import annotations
import math
from tools.base import ToolBase
from services.hv import hv_lock_project
from core.commands import AddLineCmd
from core import tracer


class LineTool(ToolBase):
    def __init__(self, app):
        super().__init__(app)
        self.start_pt = None
        self._hv_state = None
        # registruj callback pro potvrzení ručně zadaných kót
        self.app.dim.on_commit = self._on_dim_commit

    # ------------------------------------------------------------------
    # Commit z ručního zadávání (Enter v DimService)
    # ------------------------------------------------------------------

    def _on_dim_commit(self, x0: float, y0: float,
                       length: float, angle_deg: float):
        """Přijme délku+úhel z kót a potvrdí úsečku."""
        rad = math.radians(angle_deg)
        ex = x0 + length * math.cos(rad)
        ey = y0 - length * math.sin(rad)   # y-down canvas
        self._finish_line(x0, y0, ex, ey)
        self.app.dim.reset_input()

    def _finish_line(self, x0: float, y0: float, ex: float, ey: float):
        from core.types import LineSeg
        seg = LineSeg(x0, y0, ex, ey)
        self.app.history.push(AddLineCmd(self.app.doc, seg))
        tracer.trace('CMD', 'AddLine',
                     x1=round(x0,1), y1=round(y0,1),
                     x2=round(ex,1), y2=round(ey,1))
        vp = self.app.viewport
        cx1, cy1 = vp.to_canvas(x0, y0)
        cx2, cy2 = vp.to_canvas(ex, ey)
        self.app.view.draw_line(cx1, cy1, cx2, cy2)
        self.app.dim.clear()
        if getattr(self.app.cfg.flags, 'CHAIN_LINE', True):
            self.start_pt = (ex, ey)
            self._hv_state = None
            self.app.view.clear_preview()
            self.app.ldo.clear_half_axis()
        else:
            self.app.view.clear_preview()
            self.app.ldo.clear_half_axis()
            self.start_pt = None
            self._hv_state = None

    # ------------------------------------------------------------------
    # Klávesový vstup — TAB, číslice, Enter, Backspace
    # ------------------------------------------------------------------

    def on_key(self, keysym: str, char: str) -> bool:
        """Volá AppUI._on_key když je aktivní line tool."""
        if self.start_pt is None:
            return False
        # Pokud uživatel začne psát bez předchozího pohybu myši, _doc_x0/y0
        # jsou None. Inicializujeme je z start_pt aby on_commit věděl kde začít.
        dim = self.app.dim
        if dim._doc_x0 is None:
            dim._doc_x0, dim._doc_y0 = self.start_pt
        consumed, refresh_preview = dim.key_input(keysym, char)
        if consumed and refresh_preview and self.app.dim.lock_input:
            # přepočítej preview pouze po TAB (potvrzení pole), ne při psaní
            self._refresh_locked_preview()
        return consumed

    def _refresh_locked_preview(self):
        """Přepočítá preview endpoint podle dim overridů a aktualizuje kresbu."""
        if self.start_pt is None:
            return
        x0, y0 = self.start_pt
        # doc-space last endpoint (stored separately)
        dlx, dly = self.app.dim._doc_last_lx, self.app.dim._doc_last_ly

        dx = dlx - x0; dy = dly - y0
        base_L = math.hypot(dx, dy) or 1.0
        base_A = math.degrees(math.atan2(-dy, dx)) % 360

        L_ov, A_ov = self.app.dim.get_override()
        L = L_ov if L_ov is not None else base_L
        A = A_ov if A_ov is not None else base_A

        rad = math.radians(A)
        px = x0 + L * math.cos(rad)
        py = y0 - L * math.sin(rad)

        vp = self.app.viewport
        cx0, cy0 = vp.to_canvas(x0, y0)
        cpx, cpy = vp.to_canvas(px, py)
        self.app.view.preview_line(cx0, cy0, cpx, cpy)
        self.app.dim.show_length_angle(cx0, cy0, cpx, cpy,
                                       doc_x0=x0, doc_y0=y0,
                                       doc_lx=px, doc_ly=py,
                                       doc_length=L, doc_angle=A)

    # ------------------------------------------------------------------
    # Pohyb myši (ignoruje se pokud lock_input)
    # ------------------------------------------------------------------

    def _update_preview_and_half_axis(self, mx, my):
        snap_res = self.app.snap.find(mx, my) if self.app.state.snap_enabled else None
        if snap_res:
            tracer.trace('SNAP', 'find', kind=snap_res.kind,
                         x=round(snap_res.x, 1), y=round(snap_res.y, 1))
            self.app.snap_marker.propose(snap_res.kind, snap_res.x, snap_res.y)

        cx, cy = (snap_res.x, snap_res.y) if snap_res else (mx, my)

        if not self.start_pt:
            self.app.snap_marker.flush()
            self.app.view.clear_preview()
            self.app.ldo.clear_half_axis()
            self._hv_state = None
            # canvas-space pozice kurzoru pro umístění labelu
            vp = self.app.viewport
            ccx, ccy = vp.to_canvas(cx, cy)
            self.app.dim.show_cursor_coords(cx, cy, ccx, ccy)
            return

        # pokud uživatel zadává hodnoty ručně, myš neaktualizuje preview
        if self.app.dim.lock_input:
            return

        x0, y0 = self.start_pt
        lx, ly = cx, cy

        if self.app.state.snap_enabled:
            band_in  = self.app.state.hv_band_in_px
            band_out = self.app.state.hv_band_out_px
            prev_hv  = self._hv_state
            lx, ly, self._hv_state = hv_lock_project(
                x0, y0, lx, ly, self._hv_state, band_in, band_out,
                self.app.cfg.flags.AXIS_GUIDES, self.app.cfg.flags.HALF_AXES,
                self.app.ldo.half_axis, self.app.ldo.clear_half_axis
            )
            if self._hv_state != prev_hv:
                tracer.trace('HV', 'lock_change',
                             prev=prev_hv, now=self._hv_state,
                             x=round(lx,1), y=round(ly,1))
        else:
            self._hv_state = None
            self.app.ldo.clear_half_axis()

        if snap_res is None and self._hv_state is not None and self.app.state.snap_enabled:
            hv_isect = self.app.snap.find_hv_isect(x0, y0, self._hv_state, lx, ly)
            if hv_isect:
                tracer.trace('SNAP', 'hv_isect',
                             x=round(hv_isect.x,1), y=round(hv_isect.y,1),
                             hv=self._hv_state)
                self.app.snap_marker.propose(hv_isect.kind, hv_isect.x, hv_isect.y)

        self.app.snap_marker.flush()
        vp = self.app.viewport
        cx0, cy0 = vp.to_canvas(x0, y0)
        clx, cly = vp.to_canvas(lx, ly)
        doc_len = math.hypot(lx - x0, ly - y0)
        doc_ang = math.degrees(math.atan2(-(ly - y0), lx - x0)) % 360
        self.app.view.preview_line(cx0, cy0, clx, cly)
        self.app.dim.show_length_angle(cx0, cy0, clx, cly,
                                       doc_x0=x0, doc_y0=y0,
                                       doc_lx=lx, doc_ly=ly,
                                       doc_length=doc_len, doc_angle=doc_ang)

    def on_down(self, x, y, e=None):
        tracer.trace('TOOL', 'line.on_down', x=x, y=y,
                     has_start=self.start_pt is not None)
        self.app.snap_marker.clear()

        if self.start_pt is None:
            sx, sy = self.app.snap.apply(x, y) if self.app.state.snap_enabled else (x, y)
            self.start_pt = (sx, sy)
            self._hv_state = None
            self.app.view.clear_preview()
            self.app.ldo.clear_half_axis()
            self.app.dim.reset_input()
            self.app.dim.clear()
        else:
            # pokud je aktivní ruční zadávání a má override — nepotvrzuj klikem
            if self.app.dim.lock_input:
                return
            x0, y0 = self.start_pt
            ex, ey = self.app.snap.apply(x, y) if self.app.state.snap_enabled else (x, y)
            if self.app.state.snap_enabled and self._hv_state is not None:
                if self._hv_state == 'h': ey = y0
                else: ex = x0
            self._finish_line(x0, y0, ex, ey)
            self.app.dim.reset_input()

    def on_move(self, x, y, e=None):
        tracer.trace('MOVE', 'line.on_move', x=x, y=y)
        self._update_preview_and_half_axis(x, y)

    def on_up(self, x, y, e=None):
        pass

    def cancel(self):
        tracer.trace('TOOL', 'line.cancel')
        self.start_pt = None
        self._hv_state = None
        self.app.snap.reset()
        self.app.snap_marker.clear()
        self.app.view.clear_preview()
        self.app.ldo.clear_half_axis()
        self.app.dim.clear()
        self.app.dim.reset_input()
