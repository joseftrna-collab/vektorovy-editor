
# -*- coding: utf-8 -*-
from __future__ import annotations
from typing import List, Dict, Any
from core.types import DrawObject, LineSeg

# Registr: podle hodnoty 'kind' v JSON víme, jakou třídu použít.
# Při přidání nového tvaru stačí přidat jeden řádek sem.
_KIND_MAP: Dict[str, type] = {
    'line': LineSeg,
}


class Document:
    """Datový model dokumentu. Drží seznam kreslených objektů."""

    def __init__(self):
        self.objects: List[DrawObject] = []

    # --- zkratka pro zpětnou kompatibilitu s nástroji pracujícími s .lines ---
    @property
    def lines(self) -> List[LineSeg]:
        return [o for o in self.objects if isinstance(o, LineSeg)]

    def add_line(self, x1: float, y1: float, x2: float, y2: float) -> LineSeg:
        seg = LineSeg(x1, y1, x2, y2)
        self.objects.append(seg)
        return seg

    def add_object(self, obj: DrawObject) -> DrawObject:
        self.objects.append(obj)
        return obj

    def remove_object(self, obj: DrawObject) -> None:
        try:
            self.objects.remove(obj)
        except ValueError:
            pass

    def remove_line_at(self, index: int) -> None:
        """Odstraní i-tý LineSeg z dokumentu (náhrada za del doc.lines[i])."""
        target = self.lines[index]
        self.objects.remove(target)

    def insert_line_at(self, index: int, seg: 'LineSeg') -> None:  # type: ignore[name-defined]
        """Vloží LineSeg na pozici i-tého LineSeg (náhrada za doc.lines.insert(i, seg))."""
        # Najdeme odpovídající pozici v self.objects
        line_indices = [j for j, o in enumerate(self.objects)
                        if isinstance(o, __import__('core.types', fromlist=['LineSeg']).LineSeg)]
        if index >= len(line_indices):
            self.objects.append(seg)
        else:
            self.objects.insert(line_indices[index], seg)

    # --- serializace ---
    def to_json(self) -> Dict[str, Any]:
        return {'objects': [o.to_json() for o in self.objects]}

    @staticmethod
    def from_json(data: Dict[str, Any]) -> 'Document':
        d = Document()
        # podpora starého formátu ukládajícího jen 'lines'
        items = data.get('objects') or [
            {**it, 'kind': 'line'} for it in data.get('lines', [])
        ]
        for item in items:
            kind = item.get('kind', 'line')
            cls = _KIND_MAP.get(kind)
            if cls is not None:
                d.objects.append(cls.from_json(item))
        return d
