
# -*- coding: utf-8 -*-
from __future__ import annotations

class EventRouter:
    def __init__(self, app):
        self.app = app
    def motion(self, x, y, e=None): self.app.tool.on_move(x, y, e)
    def down(self, x, y, e=None): self.app.tool.on_down(x, y, e)
    def up(self, x, y, e=None): self.app.tool.on_up(x, y, e)
    def right(self, x, y, e=None):
        fn = getattr(self.app.tool, 'on_right', None)
        if callable(fn): fn(x, y, e)
