# -*- coding: utf-8 -*-
from __future__ import annotations
import tkinter as tk
from tkinter import ttk
from ui.keymap_gui import KeymapDialog
from core import tracer


class AppUI:
    """Zodpovědnost: toolbar, statusbar a klávesové zkratky.

    Dostává odkaz na App a volá jeho veřejné metody.
    Nedrží žádný stav aplikace — pouze zobrazuje a přeposílá události.
    """

    def __init__(self, app):
        self.app = app
        self._build_toolbar()
        self._build_statusbar()
        self._build_trace_panel()
        self._bind_hotkeys()
        self.refresh_status()
        # předáme UI callback do traceru
        self.app._init_tracer(ui_cb=self._trace_cb)

    # ------------------------------------------------------------------
    # Toolbar
    # ------------------------------------------------------------------
    def _setup_styles(self):
        s = ttk.Style()
        s.configure('Toolbtn.TButton', padding=4)
        s.configure('Toolbtn.Active.TButton', padding=4)
        s.map('Toolbtn.Active.TButton',
              background=[('!disabled', '#4a90d9')],
              foreground=[('!disabled', '#cc0000')])

    def _build_toolbar(self):
        app = self.app
        self._setup_styles()
        frm = ttk.Frame(app.root)
        frm.pack(side=tk.TOP, fill=tk.X)

        self._btn_selection = ttk.Button(frm, text='S - Selection',
                   style='Toolbtn.TButton',
                   command=lambda: app.set_tool('selection'))
        self._btn_selection.pack(side=tk.LEFT, padx=2)

        self._btn_line = ttk.Button(frm, text='L - Line',
                   style='Toolbtn.TButton',
                   command=lambda: app.set_tool('line'))
        self._btn_line.pack(side=tk.LEFT, padx=2)

        ttk.Separator(frm, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=6)
        ttk.Button(frm, text='Keymap…',
                   command=lambda: KeymapDialog(app)).pack(side=tk.LEFT)
        ttk.Separator(frm, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=6)
        ttk.Button(frm, text='Fit',
                   command=app.zoom_fit).pack(side=tk.LEFT, padx=2)
        ttk.Button(frm, text='1:1',
                   command=app.zoom_reset).pack(side=tk.LEFT, padx=2)
        ttk.Separator(frm, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=6)
        self._var_trace = tk.BooleanVar(value=app.cfg.trace.enabled)
        self._btn_trace = ttk.Checkbutton(frm, text='Trace',
                        variable=self._var_trace,
                        command=app.toggle_trace)
        self._btn_trace.pack(side=tk.LEFT, padx=2)

        right = ttk.Frame(frm)
        right.pack(side=tk.RIGHT)

        self._var_snap = tk.BooleanVar(value=app.state.snap_enabled)
        ttk.Checkbutton(right, text='Snap',
                        variable=self._var_snap,
                        command=app.toggle_snap).pack(side=tk.RIGHT, padx=8)

        self._var_nodes = tk.BooleanVar(value=bool(app.cfg.flags.NODES_SNAP))
        ttk.Checkbutton(right, text='Nodes',
                        variable=self._var_nodes,
                        command=app.toggle_nodes).pack(side=tk.RIGHT, padx=4)

        self._var_grid = tk.BooleanVar(value=app.snap.grid_enabled)
        ttk.Checkbutton(right, text='Grid',
                        variable=self._var_grid,
                        command=app.toggle_grid).pack(side=tk.RIGHT, padx=2)

        ttk.Button(right, text='Load…',
                   command=app.load).pack(side=tk.RIGHT, padx=2)
        ttk.Button(right, text='Save',
                   command=app.save).pack(side=tk.RIGHT, padx=2)
        ttk.Button(right, text='Save as…',
                   command=app.save_as).pack(side=tk.RIGHT, padx=2)

    # ------------------------------------------------------------------
    # Statusbar
    # ------------------------------------------------------------------
    def _build_statusbar(self):
        sb = ttk.Frame(self.app.root)
        sb.pack(side=tk.BOTTOM, fill=tk.X)
        self._var_status = tk.StringVar(value=self._status_text())
        ttk.Label(sb, textvariable=self._var_status).pack(side=tk.LEFT, padx=6)

    def refresh_status(self):
        """Volá App po každé změně stavu — aktualizuje toolbar i statusbar."""
        app = self.app
        tool = app.state.current_tool

        # Aktivní tlačítko nástroje
        self._btn_selection.configure(
            style='Toolbtn.Active.TButton' if tool == 'selection' else 'Toolbtn.TButton')
        self._btn_line.configure(
            style='Toolbtn.Active.TButton' if tool == 'line' else 'Toolbtn.TButton')

        # Checkboxy
        self._var_status.set(self._status_text())
        self._var_snap.set(app.state.snap_enabled)
        self._var_grid.set(app.snap.grid_enabled)
        self._var_nodes.set(bool(app.cfg.flags.NODES_SNAP))
        self._var_trace.set(app.cfg.trace.enabled)
        if app.cfg.trace.ui_panel:
            self._trace_frame.pack(side=tk.BOTTOM, fill=tk.X)
        else:
            self._trace_frame.pack_forget()

    def _status_text(self) -> str:
        app = self.app
        snap  = 'on' if app.state.snap_enabled else 'off'
        nodes = 'on' if app.cfg.flags.NODES_SNAP else 'off'
        grid  = 'on' if app.snap.grid_enabled else 'off'
        zoom_pct = int(round(app.viewport.scale * 100))
        base  = f"SNAP: {snap}  NODES: {nodes}  GRID: {grid}  ZOOM: {zoom_pct}%"
        modes = []
        if app.state.trim_mode:
            modes.append('TRIM')
        sel_tool = app.tools.get('selection')
        if sel_tool:
            st = getattr(sel_tool, '_st', None)
            if st is not None:
                # Počet vybraných objektů
                n = len(st.objects)
                if n > 0:
                    modes.append(f'SEL:{n}')
                if st.rotate_mode:
                    modes.append('ROTATE')
                elif st.in_region_select:
                    modes.append('REGION')
                elif st.is_dragging:
                    kind = st.active_handle or ''
                    if st.is_copy_drag:
                        modes.append('COPY')
                    elif kind in ('mid', 'corner_tl', 'corner_tr',
                                  'corner_br', 'corner_bl'):
                        modes.append('MOVE')
                    elif kind in ('end1', 'end2'):
                        modes.append('STRETCH')
        if modes:
            base += '    [' + '  '.join(modes) + ']'
        return base

    # ------------------------------------------------------------------
    # Klávesové zkratky
    # ------------------------------------------------------------------
    def _bind_hotkeys(self):
        try:
            self.app.root.bind_all('<Key>', self._on_key)
        except Exception:
            pass

    def rebind_hotkeys(self):
        """Volá App po změně keymapování."""
        self._bind_hotkeys()

    def _on_key(self, e):
        app = self.app
        k = (e.keysym or '').lower()
        km = app.cfg.keymap

        # --- deleguj TAB / číslice / Enter / Backspace na aktivní tool ---
        if app.state.current_tool == 'line':
            tool_fn = getattr(app.tool, 'on_key', None)
            if callable(tool_fn):
                if tool_fn(e.keysym or '', e.char or ''):
                    return 'break'

        if k == 's' and (e.state & 0x0004):       # Ctrl+S
            app.save(); return 'break'
        if k == 'z' and (e.state & 0x0004):       # Ctrl+Z
            app.undo(); return 'break'
        if k == 'y' and (e.state & 0x0004):       # Ctrl+Y
            app.redo(); return 'break'
        if k == 'x':
            app.state.trim_mode = not app.state.trim_mode
            app.overlays.clear(); app.view.clear_preview()
            self.refresh_status()
            return 'break'
        if k == (km.TOOL_SELECTION or 's').lower():
            app.set_tool('selection'); return 'break'
        if k == (km.TOOL_LINE or 'l').lower():
            app.set_tool('line'); return 'break'
        if k == 'f8':
            app.toggle_snap(); return 'break'
        if k == 'r' and app.state.current_tool == 'selection':
            try: app.tool.toggle_rotate_mode()
            except Exception: pass
            self.refresh_status()
            return 'break'
        if k in ('delete', 'backspace') and app.state.current_tool == 'selection':
            try: app.tool.delete_selection()
            except Exception: pass
            self.refresh_status()
            return 'break'
        if k == 'escape':
            app.state.trim_mode = False
            app.overlays.clear(); app.view.clear_preview()
            try: app.tool.cancel()
            except Exception: pass
            app.set_tool('selection'); return 'break'
        if k == 'home':
            app.zoom_fit(); return 'break'
        if k == 'end':
            app.zoom_reset(); return 'break'
        return None

    # ------------------------------------------------------------------
    # Trace panel
    # ------------------------------------------------------------------

    def _build_trace_panel(self):
        app = self.app
        self._trace_frame = ttk.Frame(app.root)
        # nezobrazujeme hned — závisí na cfg.trace.ui_panel
        inner = ttk.Frame(self._trace_frame)
        inner.pack(fill=tk.X)
        ttk.Label(inner, text='Trace:').pack(side=tk.LEFT, padx=4)
        # filter checkboxy
        self._trace_cat_vars: dict[str, tk.BooleanVar] = {}
        from core.tracer import CATEGORIES
        for cat in CATEGORIES:
            v = tk.BooleanVar(value=(cat in app.cfg.trace.categories))
            self._trace_cat_vars[cat] = v
            ttk.Checkbutton(inner, text=cat, variable=v,
                            command=self._on_trace_filter_change).pack(side=tk.LEFT)
        ttk.Button(inner, text='Clear', command=self._trace_clear).pack(side=tk.LEFT, padx=6)
        # textové pole
        self._trace_text = tk.Text(self._trace_frame, height=6, state='disabled',
                                   font=('Courier', 8), bg='#111', fg='#0f0',
                                   wrap='none')
        self._trace_text.pack(fill=tk.X)
        # zpočátku skryjeme
        if not app.cfg.trace.ui_panel:
            self._trace_frame.pack_forget()

    def _trace_cb(self, line: str):
        """Callback volaný z tracer.trace() — přidá řádek do UI panelu."""
        try:
            max_lines = self.app.cfg.trace.ui_lines
            t = self._trace_text
            t.configure(state='normal')
            t.insert('end', line + '\n')
            # ořez na max_lines
            lines = int(t.index('end-1c').split('.')[0])
            if lines > max_lines:
                t.delete('1.0', f'{lines - max_lines}.0')
            t.see('end')
            t.configure(state='disabled')
        except Exception:
            pass

    def _on_trace_filter_change(self):
        cats = [c for c, v in self._trace_cat_vars.items() if v.get()]
        self.app.cfg.trace.categories = cats
        self.app.cfg.save()
        self.app._init_tracer(ui_cb=self._trace_cb)

    def _trace_clear(self):
        try:
            self._trace_text.configure(state='normal')
            self._trace_text.delete('1.0', 'end')
            self._trace_text.configure(state='disabled')
        except Exception:
            pass
