
# -*- coding: utf-8 -*-
from __future__ import annotations
import tkinter as tk

class CanvasView:
    def __init__(self, canvas: tk.Canvas):
        self.canvas = canvas
    def clear(self):
        for tag in ('obj', 'preview', 'ghost', 'hv_axis', 'handles',
                    'snap_overlay', 'pivot', 'trim_preview'):
            try: self.canvas.delete(tag)
            except Exception: pass

    def draw_line(self, x1, y1, x2, y2, color='#000', w=1):
        self.canvas.create_line(x1, y1, x2, y2, fill=color, width=w, tags=('obj',))

    def preview_line(self, x1, y1, x2, y2):
        """Smaže veškerý preview a nakreslí jedinou čáru.

        Vhodné pro single-object náhled. Pro hromadný náhled
        (více objektů) použij clear_preview() + draw_preview_line().
        """
        try:
            self.canvas.delete('preview')
            self.canvas.create_line(x1, y1, x2, y2,
                                    fill='#000', width=1, tags=('preview',))
        except Exception:
            pass

    def draw_preview_line(self, x1, y1, x2, y2, color='#2a7fff', dash=(6, 3)):
        """Přidá preview čáru BEZ mazání předchozích.

        Volat opakovaně pro každý objekt; před smyčkou zavolej clear_preview().
        Styl odpovídá draw_ghost() — modrý dash.
        """
        try:
            self.canvas.create_line(x1, y1, x2, y2,
                                    fill=color, width=1, dash=dash,
                                    tags=('preview',))
        except Exception:
            pass

    def clear_preview(self):
        try: self.canvas.delete('preview')
        except Exception: pass

    def draw_ghost(self, x1, y1, x2, y2, color='#2a7fff', dash=(6, 3)):
        """Nakreslí ghost čáru (náhled přesunu/kopie) bez smazání předchozích.

        Volá se opakovaně pro každý objekt — všechny sdílejí tag 'ghost'.
        clear_ghost() nebo clear() je smaže najednou.
        """
        try:
            self.canvas.create_line(x1, y1, x2, y2,
                                    fill=color, width=1, dash=dash,
                                    tags=('ghost',))
        except Exception:
            pass

    def clear_ghost(self):
        try: self.canvas.delete('ghost')
        except Exception: pass
