# -*- coding: utf-8 -*-
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional


@dataclass
class SnapResult:
    x: float; y: float; kind: str


class SnapManager:
    """Správce snapování s hysterézí.

    Prahy se berou z app.state:
        tol_in  = hv_band_in_px   (přilepení)
        tol_out = hv_band_out_px  (odlepení)

    Priorita: line_end > line_mid > line_body > grid
    """

    _PRIORITY = {'line_end': 0, 'line_mid': 1, 'line_body': 2, 'grid': 3}

    def __init__(self, app, tol_px: float = 10.0):
        self.app = app
        self.tol = float(tol_px)
        self.grid_dx = 25.0
        self.grid_dy = 25.0
        self.grid_enabled = False
        self._snapped: Optional[SnapResult] = None

    # ------------------------------------------------------------------
    # Prahy
    # ------------------------------------------------------------------

    @property
    def _tol_in(self) -> float:
        tol_px = float(getattr(self.app.state, 'hv_band_in_px', self.tol))
        scale = getattr(self.app.viewport, 'scale', 1.0)
        return tol_px / scale if scale else tol_px

    @property
    def _tol_out(self) -> float:
        tol_px = float(getattr(self.app.state, 'hv_band_out_px', self.tol * 1.6))
        scale = getattr(self.app.viewport, 'scale', 1.0)
        return tol_px / scale if scale else tol_px

    # ------------------------------------------------------------------
    # Interní hledání
    # ------------------------------------------------------------------

    def _grid(self, x, y) -> SnapResult:
        gx = round((x - self.app.state.grid_ox) / self.grid_dx) * self.grid_dx + self.app.state.grid_ox
        gy = round((y - self.app.state.grid_oy) / self.grid_dy) * self.grid_dy + self.app.state.grid_oy
        return SnapResult(gx, gy, 'grid')

    def _candidates(self, x: float, y: float):
        """Vrátí seznam (d2, SnapResult) ze všech objektů v dokumentu."""
        results = []
        for obj in self.app.doc.objects:
            for (px, py, kind) in obj.snap_candidates(x, y):
                d2 = (px - x) ** 2 + (py - y) ** 2
                results.append((d2, SnapResult(px, py, kind)))
        results.sort(key=lambda r: r[0])
        return results

    def _best_within(self, x: float, y: float, tol: float) -> Optional[SnapResult]:
        tol2 = tol * tol
        best = None
        best_key = (999, 1e18)
        for d2, sr in self._candidates(x, y):
            if d2 > tol2:
                break
            key = (self._PRIORITY.get(sr.kind, 9), d2)
            if key < best_key:
                best, best_key = sr, key
        return best

    # ------------------------------------------------------------------
    # Veřejné API
    # ------------------------------------------------------------------

    def find(self, x: float, y: float) -> Optional[SnapResult]:
        """Vrátí SnapResult s hysterézí, nebo None."""
        if not self.app.state.snap_enabled:
            self._snapped = None
            return None

        if bool(self.app.cfg.flags.NODES_SNAP):
            tol_in  = self._tol_in
            tol_out = self._tol_out

            if self._snapped is not None:
                sx, sy = self._snapped.x, self._snapped.y
                d2_cur = (sx - x) ** 2 + (sy - y) ** 2
                if d2_cur <= tol_out * tol_out:
                    # zůstaneme přilepeni, ale přepneme na prioritnější
                    better = self._best_within(x, y, tol_out)
                    if better is not None:
                        self._snapped = better
                    return self._snapped
                else:
                    self._snapped = None

            candidate = self._best_within(x, y, tol_in)
            self._snapped = candidate
            return self._snapped

        if self.grid_enabled and bool(self.app.cfg.flags.GRID_SNAP):
            return self._grid(x, y)

        return None

    def apply(self, x: float, y: float):
        res = self.find(x, y)
        return (res.x, res.y) if res else (x, y)

    def apply_for_move(self, x: float, y: float):
        if not self.app.state.snap_enabled:
            return (x, y)
        if self.grid_enabled and bool(self.app.cfg.flags.GRID_SNAP):
            g = self._grid(x, y)
            return (g.x, g.y)
        return (x, y)

    def find_hv_isect(self, base_x: float, base_y: float,
                      hv: str, mx: float, my: float) -> Optional[SnapResult]:
        """Hledá průsečík poloosy se všemi objekty v dokumentu.

        Vrátí SnapResult(kind='hv_isect') pro nejbližší průsečík
        v dosahu tol_in, nebo None.
        """
        if not self.app.state.snap_enabled:
            return None
        tol_in = self._tol_in
        results = []
        for obj in self.app.doc.objects:
            pt = obj.intersect_hv_ray(base_x, base_y, hv, mx, my)
            if pt is None:
                continue
            ix, iy = pt
            d2 = (ix - mx) ** 2 + (iy - my) ** 2
            if d2 <= tol_in * tol_in:
                results.append((d2, SnapResult(ix, iy, 'hv_isect')))
        if not results:
            return None
        results.sort(key=lambda r: r[0])
        return results[0][1]

    def _ray_seg_isect(bx: float, by: float, hv: str,
                       mx: float, my: float,
                       x1: float, y1: float,
                       x2: float, y2: float):
        """Průsečík poloosy (paprsek z b ve směru hv, jen na straně myši)
        s úsečkou (x1,y1)-(x2,y2).  Vrátí (ix, iy) nebo None."""
        EPS = 1e-9
        if hv == 'h':
            # paprsek: y=by, x jde od bx směrem mx
            # úsečka musí přejít přes y=by
            dy = y2 - y1
            if abs(dy) < EPS:
                return None
            t = (by - y1) / dy
            if t < 0.0 or t > 1.0:
                return None
            ix = x1 + t * (x2 - x1)
            iy = by
            # musí být na správné straně poloosy
            if (mx >= bx and ix < bx) or (mx < bx and ix > bx):
                return None
        else:  # 'v'
            dx = x2 - x1
            if abs(dx) < EPS:
                return None
            t = (bx - x1) / dx
            if t < 0.0 or t > 1.0:
                return None
            ix = bx
            iy = y1 + t * (y2 - y1)
            if (my >= by and iy < by) or (my < by and iy > by):
                return None
        return (ix, iy)

    def reset(self):
        """Zruší přilepení — volat při cancel / změně nástroje."""
        self._snapped = None
