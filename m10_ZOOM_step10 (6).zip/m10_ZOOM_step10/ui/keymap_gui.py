
# -*- coding: utf-8 -*-
from __future__ import annotations
import tkinter as tk
from tkinter import ttk

class KeymapDialog(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app.root)
        self.title('Keymap manager')
        self.app = app
        self.resizable(False, False)
        km = app.cfg.keymap
        frm = ttk.Frame(self); frm.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        ttk.Label(frm, text='Zkratky nástrojů a akcí (Enter = uložit, Esc = zavřít)').grid(row=0, column=0, columnspan=3, sticky='w', pady=(0,8))
        labels = [('Selection [S]','TOOL_SELECTION'), ('Line [L]','TOOL_LINE')]
        self.vars = {}
        r = 1
        for label,key in labels:
            ttk.Label(frm, text=label).grid(row=r, column=0, sticky='w', pady=3)
            var = tk.StringVar(value=getattr(km, key))
            self.vars[key]=var
            ttk.Entry(frm, textvariable=var, width=12).grid(row=r, column=1, padx=8)
            ttk.Label(frm, text='např. s / l / F1…').grid(row=r, column=2, sticky='w')
            r+=1
        btns = ttk.Frame(frm); btns.grid(row=r, column=0, columnspan=3, pady=(10,0))
        ttk.Button(btns, text='Uložit', command=self._save).pack(side=tk.LEFT, padx=4)
        ttk.Button(btns, text='Reset na výchozí', command=self._reset).pack(side=tk.LEFT, padx=4)
        ttk.Button(btns, text='Zavřít', command=self.destroy).pack(side=tk.LEFT, padx=4)
        self.bind('<Return>', lambda e: self._save())
        self.bind('<Escape>', lambda e: self.destroy())
    def _save(self):
        km = self.app.cfg.keymap
        for k,v in self.vars.items():
            setattr(km, k, v.get())
        self.app.cfg.save()
        self.app.ui.rebind_hotkeys()
        self.destroy()
    def _reset(self):
        defaults = type(self.app.cfg).reset()
        self.app.cfg.keymap = defaults.keymap
        self.app.cfg.save()
        self.app.ui.rebind_hotkeys()
        self.destroy()
